import { checkHealth, getAnalyticsOverview, getHistory } from "./lib/api.js";
import { getSettings, setSetting, DEFAULT_BACKEND_URL } from "./lib/storage.js";

// --- Nav switching ---
const navItems = document.querySelectorAll(".nav-item");
const panels = document.querySelectorAll(".panel");
navItems.forEach((btn) => {
  btn.addEventListener("click", () => {
    navItems.forEach((b) => b.classList.remove("active"));
    panels.forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`panel-${btn.dataset.panel}`).classList.add("active");
    if (btn.dataset.panel === "history") loadHistory(true);
    if (btn.dataset.panel === "overview") loadOverview();
  });
});

// --- Engine / connection status (sidebar) ---
async function refreshEngineStatus() {
  const dot = document.getElementById("engineDot");
  const title = document.getElementById("engineTitle");
  const sub = document.getElementById("engineSub");
  const about = document.getElementById("aboutText");
  try {
    const health = await checkHealth();
    dot.classList.remove("bad");
    title.textContent = "Engine Active";
    sub.textContent = "Protection is running in the background.";
    if (about) {
      about.textContent =
        `Deepfake pipeline: ${health.deepfake_engine === "onnx_model+forensics"
          ? "trained ONNX model + forensic heuristics"
          : "offline forensic heuristic engine (Error Level Analysis, FFT spectral analysis, noise & illumination consistency, face/eye tracking)."} ` +
        `Misinformation pipeline: ${health.misinformation_retrieval === "local_corpus"
          ? "TF-IDF retrieval against the local curated fact-check corpus."
          : `live retrieval via ${health.misinformation_retrieval}.`} ` +
        `Server version ${health.version}, uptime ${Math.round(health.uptime_seconds)}s.`;
    }
  } catch (_err) {
    dot.classList.add("bad");
    title.textContent = "Engine Offline";
    sub.textContent = "Can't reach the backend — check Settings.";
    if (about) about.textContent = "Backend unreachable.";
  }
}

// --- Overview panel ---
async function loadOverview() {
  try {
    const data = await getAnalyticsOverview();
    document.getElementById("tileSafe").textContent = data.safe_media;
    document.getElementById("tileSuspicious").textContent = data.suspicious_items;
    document.getElementById("tileBlocked").textContent = data.deepfakes_blocked;
    drawTrendChart(data.activity_trend || []);
  } catch (_err) {
    document.getElementById("trendEmpty").hidden = false;
  }
}

function drawTrendChart(trend) {
  const canvas = document.getElementById("trendChart");
  const emptyMsg = document.getElementById("trendEmpty");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (!trend.length) {
    emptyMsg.hidden = false;
    return;
  }
  emptyMsg.hidden = true;

  const padding = { top: 14, right: 14, bottom: 26, left: 34 };
  const w = canvas.width - padding.left - padding.right;
  const h = canvas.height - padding.top - padding.bottom;
  const maxVal = Math.max(1, ...trend.map((d) => d.safe + d.suspicious + d.fake));

  // axes
  ctx.strokeStyle = "#ececf5";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padding.top + (h * i) / 4;
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(padding.left + w, y);
    ctx.stroke();
  }

  const stepX = trend.length > 1 ? w / (trend.length - 1) : 0;
  const series = [
    { key: "safe", color: "#38a169" },
    { key: "suspicious", color: "#dd6b20" },
    { key: "fake", color: "#e53e3e" },
  ];

  series.forEach(({ key, color }) => {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    trend.forEach((d, i) => {
      const x = padding.left + (trend.length > 1 ? stepX * i : w / 2);
      const y = padding.top + h - (d[key] / maxVal) * h;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    trend.forEach((d, i) => {
      const x = padding.left + (trend.length > 1 ? stepX * i : w / 2);
      const y = padding.top + h - (d[key] / maxVal) * h;
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    });
  });

  // x labels (first, middle, last)
  ctx.fillStyle = "#9494b8";
  ctx.font = "10px sans-serif";
  const labelIdxs = trend.length <= 6 ? trend.map((_, i) => i) : [0, Math.floor(trend.length / 2), trend.length - 1];
  labelIdxs.forEach((i) => {
    const x = padding.left + (trend.length > 1 ? stepX * i : w / 2);
    ctx.fillText(trend[i].day.slice(5), x - 14, canvas.height - 8);
  });
}

// --- History panel ---
let historyOffset = 0;
const HISTORY_PAGE = 20;

function verdictPillClass(verdict) {
  if (["fake", "false"].includes(verdict)) return "pill-bad";
  if (["suspicious", "misleading"].includes(verdict)) return "pill-warn";
  if (["authentic", "true"].includes(verdict)) return "pill-ok";
  return "pill-neutral";
}
function verdictLabel(verdict) {
  const map = {
    fake: "Fake", false: "False", suspicious: "Suspicious", misleading: "Misleading",
    authentic: "Authentic", true: "True", unverified: "Unverified",
  };
  return map[verdict] || verdict;
}
function confColor(verdict) {
  if (["fake", "false"].includes(verdict)) return "#e53e3e";
  if (["suspicious", "misleading"].includes(verdict)) return "#dd6b20";
  return "#38a169";
}

async function loadHistory(reset) {
  if (reset) {
    historyOffset = 0;
    document.getElementById("historyBody").innerHTML = "";
  }
  const mediaType = document.getElementById("historyFilter").value;
  try {
    const data = await getHistory({ limit: HISTORY_PAGE, offset: historyOffset, mediaType: mediaType || null });
    const tbody = document.getElementById("historyBody");
    const emptyMsg = document.getElementById("historyEmpty");

    if (reset && data.items.length === 0) {
      emptyMsg.hidden = false;
    } else {
      emptyMsg.hidden = true;
    }

    for (const item of data.items) {
      const tr = document.createElement("tr");
      const time = new Date(item.created_at * 1000).toLocaleString();
      const pct = Math.round((item.confidence || 0) * 100);
      tr.innerHTML = `
        <td>${item.media_type[0].toUpperCase() + item.media_type.slice(1)} Analysis</td>
        <td class="src-cell" title="${escapeAttr(item.source_url || "")}">${escapeHtml(item.source_url || "Unknown source")}</td>
        <td><span class="result-pill ${verdictPillClass(item.verdict)}">${verdictLabel(item.verdict)}</span></td>
        <td>
          <span class="conf-bar-wrap"><span class="conf-bar" style="width:${pct}%; background:${confColor(item.verdict)}"></span></span>
          ${pct}%
        </td>
        <td>${time}</td>`;
      tbody.appendChild(tr);
    }
    historyOffset += data.items.length;
    document.getElementById("historyLoadMore").hidden = historyOffset >= data.total;
  } catch (_err) {
    document.getElementById("historyEmpty").hidden = false;
  }
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}
function escapeAttr(s) {
  return String(s).replace(/"/g, "&quot;");
}

document.getElementById("historyFilter").addEventListener("change", () => loadHistory(true));
document.getElementById("historyRefresh").addEventListener("click", () => loadHistory(true));
document.getElementById("historyLoadMore").addEventListener("click", () => loadHistory(false));

// --- Settings panel ---
async function loadSettingsPanel() {
  const settings = await getSettings();
  document.getElementById("backendUrl").value = settings.backendUrl || DEFAULT_BACKEND_URL;
  document.getElementById("autoScanToggle").checked = !!settings.autoScanEnabled;
}

document.getElementById("testConnection").addEventListener("click", async () => {
  const url = document.getElementById("backendUrl").value.trim().replace(/\/+$/, "");
  const msg = document.getElementById("connStatusMsg");
  msg.textContent = "Testing…";
  msg.className = "status-msg";
  try {
    const resp = await fetch(`${url}/api/v1/health`);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const health = await resp.json();
    msg.textContent = `✓ Connection successful and verified (v${health.version}).`;
    msg.className = "status-msg ok";
  } catch (err) {
    msg.textContent = `✕ Could not connect: ${err.message}`;
    msg.className = "status-msg bad";
  }
});

document.getElementById("saveSettings").addEventListener("click", async () => {
  const url = document.getElementById("backendUrl").value.trim().replace(/\/+$/, "") || DEFAULT_BACKEND_URL;
  const autoScan = document.getElementById("autoScanToggle").checked;
  await setSetting("backendUrl", url);
  await setSetting("autoScanEnabled", autoScan);
  const msg = document.getElementById("saveMsg");
  msg.textContent = "Preferences saved successfully!";
  msg.className = "status-msg ok";
  setTimeout(() => (msg.textContent = ""), 3000);
  refreshEngineStatus();
});

// --- Init ---
loadOverview();
loadSettingsPanel();
refreshEngineStatus();
