import { checkHealth, getAnalyticsOverview, ApiError } from "./lib/api.js";

const connDot = document.getElementById("connStatus");
const connMsg = document.getElementById("connMsg");
const statSafe = document.getElementById("statSafe");
const statSuspicious = document.getElementById("statSuspicious");
const statBlocked = document.getElementById("statBlocked");

document.getElementById("openDashboard").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

async function refresh() {
  try {
    await checkHealth();
    connDot.className = "conn-dot conn-ok";
    connDot.title = "Connected to backend";
    connMsg.textContent = "";
  } catch (err) {
    connDot.className = "conn-dot conn-bad";
    connDot.title = "Not connected";
    connMsg.textContent =
      err instanceof ApiError || err
        ? "Backend unreachable — check the URL in Settings."
        : "";
  }

  try {
    const overview = await getAnalyticsOverview();
    statSafe.textContent = overview.safe_media ?? "–";
    statSuspicious.textContent = overview.suspicious_items ?? "–";
    statBlocked.textContent = overview.deepfakes_blocked ?? "–";
  } catch (_err) {
    statSafe.textContent = statSuspicious.textContent = statBlocked.textContent = "–";
  }
}

refresh();
