// VeriMedia background service worker.
// Owns: context menu registration, fetching flagged media, calling the
// backend, and relaying results to the content script for the interstitial
// warning overlay (Figure 3-5) / badge updates.

import * as api from "./lib/api.js";
import { getSettings, setSetting } from "./lib/storage.js";

const MENU_IMAGE_VIDEO = "verimedia-verify-media";
const MENU_SELECTION = "verimedia-verify-text";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_IMAGE_VIDEO,
    title: "Verify Media (Image/Video) with VeriMedia",
    contexts: ["image", "video"],
  });
  chrome.contextMenus.create({
    id: MENU_SELECTION,
    title: 'Fact-check "%s" with VeriMedia',
    contexts: ["selection"],
  });
});

function setBadge(text, color) {
  chrome.action.setBadgeText({ text: text || "" });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

function badgeForVerdict(verdict) {
  const map = {
    fake: ["!", "#E53E3E"],
    false: ["!", "#E53E3E"],
    suspicious: ["?", "#DD6B20"],
    misleading: ["?", "#DD6B20"],
    authentic: ["✓", "#38A169"],
    true: ["✓", "#38A169"],
    unverified: ["…", "#718096"],
  };
  return map[verdict] || ["", "#718096"];
}

async function notify(title, message, iconUrl = "icons/icon128.png") {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl,
      title,
      message,
      priority: 1,
    });
  } catch (_e) {
    /* notifications permission may be restricted on some platforms */
  }
}

async function fetchAsBlob(url) {
  const resp = await fetch(url, { credentials: "omit" });
  if (!resp.ok) throw new Error(`Could not fetch media (${resp.status})`);
  return resp.blob();
}

async function handleVerifyMedia(info, tab) {
  const isVideo = !!info.srcUrl && info.mediaType === "video";
  const srcUrl = info.srcUrl;
  if (!srcUrl) return;

  chrome.tabs.sendMessage(tab.id, {
    type: "VERIMEDIA_ANALYSIS_STARTED",
    srcUrl,
  }).catch(() => {});
  setBadge("…", "#718096");

  try {
    const blob = await fetchAsBlob(srcUrl);
    const result = isVideo
      ? await api.analyzeVideoBlob(blob, tab.url, "video.mp4", false)
      : await api.analyzeImageBlob(blob, tab.url, "image.jpg");

    const [badgeText, badgeColor] = badgeForVerdict(result.verdict);
    setBadge(badgeText, badgeColor);

    chrome.tabs.sendMessage(tab.id, {
      type: "VERIMEDIA_ANALYSIS_RESULT",
      srcUrl,
      result,
    }).catch(() => {});

    if (result.verdict === "fake" || result.verdict === "suspicious") {
      notify(
        "VeriMedia: potential manipulation detected",
        `${Math.round(result.confidence * 100)}% confidence — ${result.anomalies?.[0] || "review recommended"}`
      );
    }
  } catch (err) {
    chrome.tabs.sendMessage(tab.id, {
      type: "VERIMEDIA_ANALYSIS_ERROR",
      srcUrl,
      error: String(err.message || err),
    }).catch(() => {});
    setBadge("×", "#718096");
    notify("VeriMedia couldn't complete that scan", String(err.message || err));
  }
}

async function handleVerifyText(info, tab) {
  const text = info.selectionText;
  if (!text) return;

  chrome.tabs.sendMessage(tab.id, { type: "VERIMEDIA_TEXT_STARTED" }).catch(() => {});
  setBadge("…", "#718096");

  try {
    const result = await api.analyzeText(text, tab.url);
    const [badgeText, badgeColor] = badgeForVerdict(result.verdict);
    setBadge(badgeText, badgeColor);

    chrome.tabs.sendMessage(tab.id, {
      type: "VERIMEDIA_TEXT_RESULT",
      result,
    }).catch(() => {});

    if (result.verdict === "false" || result.verdict === "misleading") {
      notify(
        "VeriMedia: possible misinformation detected",
        `${Math.round(result.confidence * 100)}% confidence — ${result.summary}`
      );
    }
  } catch (err) {
    chrome.tabs.sendMessage(tab.id, {
      type: "VERIMEDIA_TEXT_ERROR",
      error: String(err.message || err),
    }).catch(() => {});
    setBadge("×", "#718096");
    notify("VeriMedia couldn't complete that fact-check", String(err.message || err));
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === MENU_IMAGE_VIDEO) {
    handleVerifyMedia(info, tab);
  } else if (info.menuItemId === MENU_SELECTION) {
    handleVerifyText(info, tab);
  }
});

// Exposes the exact same handlers the real context-menu click path uses, so
// automated tests can drive them directly (Chrome's native context menu
// itself is outside what browser automation can click). Not used by any
// production code path.
self.__verimediaTestHooks = { handleVerifyMedia, handleVerifyText };

// Messages from content.js (auto-scan candidates) and popup.js/dashboard.js
// (on-demand actions that need background's cross-origin fetch capability).
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "VERIMEDIA_AUTOSCAN_CANDIDATES") {
    (async () => {
      const settings = await getSettings();
      if (!settings.autoScanEnabled) return;
      const tabId = sender.tab?.id;
      const tabUrl = sender.tab?.url;
      if (!tabId) return;
      const urls = (message.urls || []).slice(0, settings.autoScanMaxImages);
      for (const url of urls) {
        try {
          const blob = await fetchAsBlob(url);
          const result = await api.analyzeImageBlob(blob, tabUrl, "image.jpg");
          chrome.tabs.sendMessage(tabId, {
            type: "VERIMEDIA_AUTOSCAN_RESULT",
            srcUrl: url,
            result,
          }).catch(() => {});
        } catch (_e) {
          // silently skip media that can't be fetched (CORS/hotlink-protected, etc.)
        }
      }
    })();
    return false;
  }

  if (message?.type === "VERIMEDIA_PING_BACKEND") {
    api.checkHealth().then(
      (health) => sendResponse({ ok: true, health }),
      (err) => sendResponse({ ok: false, error: String(err.message || err) })
    );
    return true; // async response
  }

  if (message?.type === "VERIMEDIA_SET_SETTING") {
    setSetting(message.key, message.value).then(() => sendResponse({ ok: true }));
    return true;
  }

  return false;
});
