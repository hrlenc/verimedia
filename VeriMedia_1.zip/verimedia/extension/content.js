// VeriMedia content script.
// Renders the interstitial warning overlay (Figure 3-5) over flagged
// images/video, a floating result panel for text fact-checks, and
// (optionally) collects visible-image candidates for background auto-scan.

(() => {
  const NS = "verimedia";
  let lastContextTarget = null;
  let shadowHost = null;
  let shadowRoot = null;
  const activeCards = new Map(); // key -> { card, targetEl, placement }

  document.addEventListener(
    "contextmenu",
    (e) => {
      const el = e.target;
      if (el && (el.tagName === "IMG" || el.tagName === "VIDEO")) {
        lastContextTarget = el;
      }
    },
    true
  );

  function ensureShadow() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement("div");
    shadowHost.id = "verimedia-shadow-host";
    shadowHost.style.cssText = "position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;";
    document.documentElement.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CARD_CSS;
    shadowRoot.appendChild(style);
    return shadowRoot;
  }

  function resolveTargetForSrc(srcUrl) {
    if (lastContextTarget) {
      const t = lastContextTarget;
      const cur = t.currentSrc || t.src || "";
      if (cur === srcUrl || cur.endsWith(srcUrl) || srcUrl.endsWith(cur)) return t;
    }
    const els = document.querySelectorAll("img, video, source");
    for (const el of els) {
      const cur = el.currentSrc || el.src || "";
      if (cur === srcUrl) return el.tagName === "SOURCE" ? el.closest("video") || el : el;
    }
    return lastContextTarget;
  }

  function positionCard(card, targetEl) {
    if (!targetEl) {
      card.style.position = "fixed";
      card.style.top = "16px";
      card.style.right = "16px";
      card.style.left = "auto";
      return;
    }
    const rect = targetEl.getBoundingClientRect();
    const cardWidth = 300;
    let left = rect.left + rect.width / 2 - cardWidth / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - cardWidth - 8));
    let top = rect.bottom - 8;
    if (top + 140 > window.innerHeight) top = Math.max(8, rect.top - 148);
    card.style.position = "fixed";
    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
    card.style.right = "auto";
  }

  function repositionAll() {
    for (const { card, targetEl } of activeCards.values()) {
      if (document.contains(card.__anchorEl || document.body)) positionCard(card, targetEl);
    }
  }
  window.addEventListener("scroll", repositionAll, true);
  window.addEventListener("resize", repositionAll);

  function verdictMeta(verdict) {
    const table = {
      fake: { label: "Likely Manipulated", cls: "vm-bad", icon: "⚠" },
      false: { label: "Likely False", cls: "vm-bad", icon: "⚠" },
      suspicious: { label: "Suspicious", cls: "vm-warn", icon: "❗" },
      misleading: { label: "Misleading", cls: "vm-warn", icon: "❗" },
      authentic: { label: "No Anomalies Found", cls: "vm-ok", icon: "✓" },
      true: { label: "Supported", cls: "vm-ok", icon: "✓" },
      unverified: { label: "Unverified", cls: "vm-neutral", icon: "?" },
    };
    return table[verdict] || table.unverified;
  }

  function makeCard(key, html, targetEl) {
    const root = ensureShadow();
    removeCard(key);
    const card = document.createElement("div");
    card.className = "vm-card";
    card.innerHTML = html;
    root.appendChild(card);
    positionCard(card, targetEl);
    activeCards.set(key, { card, targetEl });
    return card;
  }

  function removeCard(key) {
    const entry = activeCards.get(key);
    if (entry) {
      entry.card.remove();
      activeCards.delete(key);
    }
  }

  function showMediaStarted(srcUrl) {
    const targetEl = resolveTargetForSrc(srcUrl);
    makeCard(
      `media:${srcUrl}`,
      `<div class="vm-header"><span class="vm-dot vm-pulse"></span><span class="vm-title">VeriMedia</span><span class="vm-badge-online">ANALYZING</span></div>
       <div class="vm-body"><div class="vm-spinner"></div><span>Running dual-pipeline analysis…</span></div>`,
      targetEl
    );
  }

  function showMediaResult(srcUrl, result) {
    const targetEl = resolveTargetForSrc(srcUrl);
    const meta = verdictMeta(result.verdict);
    const pct = Math.round((result.confidence || 0) * 100);
    const flagged = result.verdict === "fake" || result.verdict === "suspicious";

    if (targetEl && flagged) {
      targetEl.classList.add("verimedia-blurred");
    }

    const anomaliesHtml = (result.anomalies || [])
      .slice(0, 2)
      .map((a) => `<li>${escapeHtml(a)}</li>`)
      .join("");

    const key = `media:${srcUrl}`;
    const card = makeCard(
      key,
      `<div class="vm-header"><span class="vm-dot"></span><span class="vm-title">VeriMedia</span><span class="vm-badge-online">ONLINE</span></div>
       <div class="vm-result-title">MEDIA ANALYSIS <span class="vm-pct ${meta.cls}">${pct}% Confidence</span></div>
       <div class="vm-verdict ${meta.cls}">${meta.icon} ${meta.label}</div>
       <div class="vm-sub">Analysis completed in ${(result.processing_time_ms / 1000).toFixed(2)}s${result.frames_sampled ? ` · ${result.frames_sampled} frames sampled` : ""}${result.cached ? " · cached result" : ""}</div>
       ${anomaliesHtml ? `<ul class="vm-anomalies">${anomaliesHtml}</ul>` : ""}
       <div class="vm-actions">
         ${flagged ? `<button class="vm-btn vm-btn-primary" data-action="reveal">Reveal Anyway</button>` : ""}
         <button class="vm-btn" data-action="dismiss">Dismiss</button>
       </div>`,
      targetEl
    );

    card.querySelector('[data-action="dismiss"]')?.addEventListener("click", () => removeCard(key));
    card.querySelector('[data-action="reveal"]')?.addEventListener("click", (e) => {
      if (targetEl) targetEl.classList.toggle("verimedia-revealed");
      e.target.textContent = targetEl?.classList.contains("verimedia-revealed") ? "Hide Again" : "Reveal Anyway";
    });
  }

  function showMediaError(srcUrl, error) {
    const targetEl = resolveTargetForSrc(srcUrl);
    const key = `media:${srcUrl}`;
    const card = makeCard(
      key,
      `<div class="vm-header"><span class="vm-dot vm-dot-error"></span><span class="vm-title">VeriMedia</span></div>
       <div class="vm-body">Couldn't analyze this media: ${escapeHtml(error)}</div>
       <div class="vm-actions"><button class="vm-btn" data-action="dismiss">Dismiss</button></div>`,
      targetEl
    );
    card.querySelector('[data-action="dismiss"]')?.addEventListener("click", () => removeCard(key));
  }

  function showTextStarted() {
    makeCard(
      "text",
      `<div class="vm-header"><span class="vm-dot vm-pulse"></span><span class="vm-title">VeriMedia</span><span class="vm-badge-online">ANALYZING</span></div>
       <div class="vm-body"><div class="vm-spinner"></div><span>Fact-checking selected text…</span></div>`,
      null
    );
  }

  function showTextResult(result) {
    const meta = verdictMeta(result.verdict);
    const pct = Math.round((result.confidence || 0) * 100);
    const card = makeCard(
      "text",
      `<div class="vm-header"><span class="vm-dot"></span><span class="vm-title">VeriMedia</span><span class="vm-badge-online">ONLINE</span></div>
       <div class="vm-result-title">TEXT ANALYSIS <span class="vm-pct ${meta.cls}">${pct}% Confidence</span></div>
       <div class="vm-verdict ${meta.cls}">${meta.icon} ${meta.label}</div>
       <div class="vm-claim">"${escapeHtml(truncate(result.extracted_claim || "", 140))}"</div>
       <div class="vm-sub">${escapeHtml(truncate(result.summary || "", 220))}</div>
       <div class="vm-actions"><button class="vm-btn" data-action="dismiss">Dismiss</button></div>`,
      null
    );
    card.querySelector('[data-action="dismiss"]')?.addEventListener("click", () => removeCard("text"));
  }

  function showTextError(error) {
    const card = makeCard(
      "text",
      `<div class="vm-header"><span class="vm-dot vm-dot-error"></span><span class="vm-title">VeriMedia</span></div>
       <div class="vm-body">Couldn't fact-check this text: ${escapeHtml(error)}</div>
       <div class="vm-actions"><button class="vm-btn" data-action="dismiss">Dismiss</button></div>`,
      null
    );
    card.querySelector('[data-action="dismiss"]')?.addEventListener("click", () => removeCard("text"));
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }
  function truncate(s, n) {
    return s.length > n ? s.slice(0, n) + "…" : s;
  }

  chrome.runtime.onMessage.addListener((message) => {
    switch (message?.type) {
      case "VERIMEDIA_ANALYSIS_STARTED":
        showMediaStarted(message.srcUrl);
        break;
      case "VERIMEDIA_ANALYSIS_RESULT":
        showMediaResult(message.srcUrl, message.result);
        break;
      case "VERIMEDIA_ANALYSIS_ERROR":
        showMediaError(message.srcUrl, message.error);
        break;
      case "VERIMEDIA_TEXT_STARTED":
        showTextStarted();
        break;
      case "VERIMEDIA_TEXT_RESULT":
        showTextResult(message.result);
        break;
      case "VERIMEDIA_TEXT_ERROR":
        showTextError(message.error);
        break;
      case "VERIMEDIA_AUTOSCAN_RESULT":
        if (message.result?.verdict === "fake" || message.result?.verdict === "suspicious") {
          showMediaResult(message.srcUrl, message.result);
        }
        break;
    }
  });

  // --- Optional auto-scan of visible images (off by default; toggled in
  // dashboard Settings). Only large, likely-content images are considered
  // to avoid wasting requests on icons/sprites/ads.
  chrome.storage.local.get(["autoScanEnabled"], ({ autoScanEnabled }) => {
    if (!autoScanEnabled) return;
    const candidates = Array.from(document.querySelectorAll("img"))
      .filter((img) => img.naturalWidth >= 200 && img.naturalHeight >= 200)
      .map((img) => img.currentSrc || img.src)
      .filter(Boolean);
    const unique = Array.from(new Set(candidates)).slice(0, 8);
    if (unique.length) {
      chrome.runtime.sendMessage({ type: "VERIMEDIA_AUTOSCAN_CANDIDATES", urls: unique });
    }
  });

  const CARD_CSS = `
    .vm-card { position:fixed; width:300px; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
      background:#1a1a2e; color:#f1f1f5; border-radius:12px; box-shadow:0 12px 32px rgba(0,0,0,0.35);
      padding:14px; font-size:13px; line-height:1.4; pointer-events:auto; border:1px solid rgba(255,255,255,0.08); }
    .vm-header { display:flex; align-items:center; gap:8px; margin-bottom:8px; }
    .vm-dot { width:8px; height:8px; border-radius:50%; background:#38A169; display:inline-block; }
    .vm-dot-error { background:#E53E3E; }
    .vm-pulse { animation: vm-pulse 1.2s infinite; }
    @keyframes vm-pulse { 0%{opacity:1;} 50%{opacity:0.3;} 100%{opacity:1;} }
    .vm-title { font-weight:700; font-size:13px; color:#fff; }
    .vm-badge-online { margin-left:auto; font-size:10px; letter-spacing:0.04em; color:#9f9fce; border:1px solid #3a3a5c; padding:2px 6px; border-radius:999px; }
    .vm-body { display:flex; align-items:center; gap:8px; color:#c7c7dd; }
    .vm-spinner { width:14px; height:14px; border-radius:50%; border:2px solid #4a4a7a; border-top-color:#7c6cf0; animation:vm-spin 0.8s linear infinite; }
    @keyframes vm-spin { to { transform:rotate(360deg); } }
    .vm-result-title { font-size:11px; letter-spacing:0.05em; color:#9f9fce; display:flex; justify-content:space-between; margin-bottom:4px; }
    .vm-pct { font-weight:700; }
    .vm-verdict { font-size:15px; font-weight:700; margin-bottom:4px; }
    .vm-sub { color:#a7a7c9; font-size:12px; margin-bottom:6px; }
    .vm-claim { font-style:italic; color:#dcdcf5; font-size:12px; margin-bottom:6px; border-left:2px solid #7c6cf0; padding-left:8px; }
    .vm-anomalies { margin:0 0 8px 0; padding-left:18px; color:#e3c56b; font-size:12px; }
    .vm-ok { color:#48d98a; }
    .vm-warn { color:#f0b13d; }
    .vm-bad { color:#f26d6d; }
    .vm-neutral { color:#9f9fce; }
    .vm-actions { display:flex; gap:8px; margin-top:6px; }
    .vm-btn { flex:1; background:#2c2c4a; color:#fff; border:1px solid #40406b; border-radius:8px; padding:6px 8px; font-size:12px; cursor:pointer; }
    .vm-btn:hover { background:#38386080; }
    .vm-btn-primary { background:#5b4ce6; border-color:#5b4ce6; }
    .vm-btn-primary:hover { background:#6c5df2; }
  `;
})();
