"""
Reference example (NOT runnable in this sandbox — needs torch/timm and a
trained checkpoint) showing how to export a trained EfficientNet deepfake
classifier to the ONNX file `app/pipelines/model_backend.py` loads.

Run this on your own machine, after training, with:
    pip install torch torchvision timm onnx
    python scripts/export_onnx_example.py --checkpoint path/to/model.pt --out model.onnx

Then point the backend at it:
    # backend/.env
    VERIMEDIA_ONNX_MODEL_PATH=/absolute/path/to/model.onnx
"""
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True, help="Path to your trained PyTorch checkpoint (.pt/.pth)")
    parser.add_argument("--out", required=True, help="Output .onnx path")
    parser.add_argument("--arch", default="efficientnet_b0", help="timm architecture name")
    args = parser.parse_args()

    import torch
    import timm

    model = timm.create_model(args.arch, pretrained=False, num_classes=1)  # 1 logit: P(fake)
    state_dict = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(state_dict)
    model.eval()

    dummy = torch.randn(1, 3, 224, 224)
    torch.onnx.export(
        model,
        dummy,
        args.out,
        input_names=["input"],
        output_names=["logits"],
        dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}},
        opset_version=17,
    )
    print(f"Exported ONNX model to {args.out}")
    print("Set VERIMEDIA_ONNX_MODEL_PATH to this path in backend/.env and restart the backend.")


if __name__ == "__main__":
    main()
