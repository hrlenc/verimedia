"""
Reference example (NOT runnable in this sandbox — needs torch and a trained
checkpoint) showing how to convert a trained `torch.nn.GRU` (+ a linear
output head) into the `.npz` weight file that
`app/pipelines/model_backend.NumpyGRU` loads for video temporal scoring.

Run on your own machine after training:
    pip install torch numpy
    python scripts/export_gru_weights.py --checkpoint path/to/gru_model.pt --out model.gru.npz

`model.gru.npz` must sit next to the ONNX file configured via
VERIMEDIA_ONNX_MODEL_PATH, with the same basename
(e.g. `model.onnx` + `model.gru.npz`) — see model_backend.py's `_load()`.
"""
import argparse

import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    import torch

    ckpt = torch.load(args.checkpoint, map_location="cpu")
    gru: torch.nn.GRU = ckpt["gru"]           # a single-layer nn.GRU
    head: torch.nn.Linear = ckpt["head"]      # nn.Linear(hidden_size, 1)

    # PyTorch packs the GRU's input-hidden and hidden-hidden weights as
    # concatenated [reset, update, new] gate blocks; split them out into the
    # per-gate matrices NumpyGRU.forward() expects.
    hidden_size = gru.hidden_size
    w_ih = gru.weight_ih_l0.detach().numpy()  # (3*hidden, input)
    w_hh = gru.weight_hh_l0.detach().numpy()  # (3*hidden, hidden)
    b_ih = gru.bias_ih_l0.detach().numpy()
    b_hh = gru.bias_hh_l0.detach().numpy()

    W_ir, W_iz, W_in = np.split(w_ih, 3, axis=0)
    W_hr, W_hz, W_hn = np.split(w_hh, 3, axis=0)
    b_ir, b_iz, b_in = np.split(b_ih, 3, axis=0)
    b_hr, b_hz, b_hn = np.split(b_hh, 3, axis=0)

    np.savez(
        args.out,
        W_ir=W_ir, W_iz=W_iz, W_in=W_in,
        W_hr=W_hr, W_hz=W_hz, W_hn=W_hn,
        b_ir=b_ir, b_iz=b_iz, b_in=b_in,
        b_hr=b_hr, b_hz=b_hz, b_hn=b_hn,
        W_out=head.weight.detach().numpy().squeeze(0),
        b_out=head.bias.detach().numpy(),
    )
    print(f"Exported GRU weights to {args.out} (hidden_size={hidden_size})")


if __name__ == "__main__":
    main()
