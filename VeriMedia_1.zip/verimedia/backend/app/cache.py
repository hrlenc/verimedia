"""
Content-addressed cache — the "caching mechanism verifies whether submitted
content has been previously analyzed" step from the architecture (p.46).
Keyed by a hash of the content itself, so re-scanning the same image/video/
text (a common case: the same viral post analyzed by many users, or a user
re-checking a page) skips the analysis pipeline entirely.
"""
from __future__ import annotations

from typing import Callable, Optional

from . import db
from .config import config


def get_or_compute(cache_key: str, compute: Callable[[], dict]) -> tuple[dict, bool]:
    """Returns (result, was_cached)."""
    cached = db.cache_get(cache_key)
    if cached is not None:
        return cached, True
    result = compute()
    db.cache_set(cache_key, result, config.CACHE_TTL_SECONDS)
    return result, False
