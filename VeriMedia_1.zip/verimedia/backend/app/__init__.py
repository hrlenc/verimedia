from __future__ import annotations

import logging

from flask import Flask, jsonify

from .config import config
from . import db as db_module


def create_app() -> Flask:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 150 * 1024 * 1024  # 150MB hard cap (videos)

    with app.app_context():
        db_module.init_db()

    from .routes import analyze, history, settings as settings_route, pages

    app.register_blueprint(analyze.bp)
    app.register_blueprint(history.bp)
    app.register_blueprint(settings_route.bp)
    app.register_blueprint(pages.bp)

    @app.after_request
    def add_cors_headers(resp):
        origin = config.ALLOWED_ORIGINS
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        resp.headers["Access-Control-Max-Age"] = "3600"
        return resp

    @app.route("/api/v1/<path:_any>", methods=["OPTIONS"])
    def cors_preflight(_any):
        return "", 204

    @app.errorhandler(413)
    def too_large(_exc):
        return jsonify(error="Upload exceeds the server's maximum allowed size."), 413

    @app.errorhandler(404)
    def not_found(_exc):
        return jsonify(error="Not found."), 404

    @app.errorhandler(500)
    def server_error(exc):
        app.logger.exception("Unhandled server error")
        return jsonify(error="Internal server error."), 500

    @app.get("/")
    def root():
        return jsonify(
            service="VeriMedia backend",
            docs="See README.md for the API reference.",
            endpoints=[
                "POST /api/v1/analyze/image", "POST /api/v1/analyze/video",
                "POST /api/v1/analyze/text", "GET /api/v1/jobs/<id>",
                "GET /api/v1/history", "GET /api/v1/analytics/overview",
                "GET /api/v1/health",
            ],
        ), 200

    return app
