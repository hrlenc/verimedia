"""
Cache & Task Queue System (Figure 3-13).

Video analysis is the one operation expensive enough to need to happen off
the request thread. This module gives a minimal, dependency-free async task
queue: a bounded thread pool draining an in-memory `queue.Queue`, with job
state persisted to sqlite (app.db) so `GET /api/v1/jobs/<id>` can poll it.

This is intentionally swappable: in production, replace `submit()`'s body
with `celery_task.delay(...)` and keep the same call sites — see README
"Scaling the task queue".
"""
from __future__ import annotations

import queue
import threading
import traceback
from typing import Callable

from . import db

_task_queue: "queue.Queue[tuple[str, Callable[[], dict]]]" = queue.Queue()
_WORKERS = 2
_started = False
_lock = threading.Lock()


def _worker_loop() -> None:
    while True:
        job_id, fn = _task_queue.get()
        try:
            db.update_job(job_id, status="processing")
            result = fn()
            db.update_job(job_id, status="done", result=result)
        except Exception as exc:  # noqa: BLE001
            db.update_job(job_id, status="error", error=f"{exc}\n{traceback.format_exc()}")
        finally:
            _task_queue.task_done()


def start_workers() -> None:
    global _started
    with _lock:
        if _started:
            return
        for _ in range(_WORKERS):
            t = threading.Thread(target=_worker_loop, daemon=True)
            t.start()
        _started = True


def submit(job_id: str, media_type: str, fn: Callable[[], dict]) -> None:
    """Queue `fn` (a zero-arg callable that returns a JSON-serialisable dict)
    to run asynchronously under `job_id`. Caller must already have created
    the job row via `db.create_job`."""
    start_workers()
    _task_queue.put((job_id, fn))
