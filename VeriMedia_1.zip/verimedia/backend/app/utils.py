"""Small shared helpers: hashing, image decoding, and response shaping."""
from __future__ import annotations

import hashlib
import io
from typing import Optional

import numpy as np
from PIL import Image


def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_text(text: str) -> str:
    return hashlib.sha256(text.strip().lower().encode("utf-8")).hexdigest()


def load_image_from_bytes(data: bytes) -> Image.Image:
    """Decode bytes to a PIL RGB image. Raises ValueError on bad input."""
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Could not decode image: {exc}") from exc
    if img.mode != "RGB":
        img = img.convert("RGB")
    return img


def pil_to_bgr_ndarray(img: Image.Image) -> np.ndarray:
    import cv2

    arr = np.array(img)  # RGB
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def verdict_from_score(score: float, flag_threshold: float, suspicious_threshold: float) -> str:
    if score >= flag_threshold:
        return "fake"
    if score >= suspicious_threshold:
        return "suspicious"
    return "authentic"
