"""Health/connection-test route used by the extension's System Settings
panel (Figure 3-8) 'Test Connection' button."""
from __future__ import annotations

import time

from flask import Blueprint, jsonify

from ..config import config
from ..pipelines.model_backend import get_model_backend

bp = Blueprint("settings", __name__, url_prefix="/api/v1")

_START = time.time()


@bp.get("/health")
def health():
    backend = get_model_backend()
    return jsonify(
        status="ok",
        service="VeriMedia backend",
        version="1.0.0",
        uptime_seconds=round(time.time() - _START, 1),
        deep_model_loaded=backend.available,
        deepfake_engine="onnx_model+forensics" if backend.available else "forensics_heuristic",
        misinformation_retrieval=config.LIVE_RETRIEVAL_PROVIDER or "local_corpus",
    ), 200
