"""Plain HTML pages served by the backend itself — mainly the privacy
policy, so the Chrome Web Store listing has a stable, always-on URL to
point at (no separate hosting needed)."""
from __future__ import annotations

from flask import Blueprint, Response

bp = Blueprint("pages", __name__)

PRIVACY_POLICY_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>VeriMedia — Privacy Policy</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
         max-width: 720px; margin: 40px auto; padding: 0 20px; color: #1a1a2e; line-height: 1.6; }
  h1 { font-size: 24px; } h2 { font-size: 16px; margin-top: 28px; }
  code { background: #f2f2f8; padding: 1px 5px; border-radius: 4px; font-size: 13px; }
  .updated { color: #7a7a99; font-size: 13px; }
</style>
</head>
<body>
<h1>VeriMedia — Privacy Policy</h1>
<p class="updated">Last updated: 2026</p>

<p>VeriMedia is a browser extension developed as a BSCS thesis project at
City College of Calamba that helps users check whether an image, video, or
piece of text they encounter online shows signs of digital manipulation
(deepfakes) or misinformation. This page explains what the extension does
with your data.</p>

<h2>What VeriMedia analyzes</h2>
<p>VeriMedia only analyzes content you explicitly choose to check:</p>
<ul>
  <li>An image or video you right-click and select "Verify Media (Image/Video)
      with VeriMedia" for.</li>
  <li>Text you select and choose to fact-check.</li>
  <li>If you turn on the optional "Auto-protect" setting (off by default), a
      handful of large images on pages you visit are scanned automatically
      in the background.</li>
</ul>

<h2>What is sent to our server</h2>
<p>The image/video bytes or selected text, together with the URL of the page
you were on, are sent over HTTPS to VeriMedia's backend server for
analysis. The server returns a verdict (e.g. authentic/suspicious/fake or
true/misleading/false), a confidence score, and — for transparency — the
specific technical signals that produced that verdict.</p>

<h2>What we store</h2>
<p>To power the extension's History and Analytics dashboard, the backend
stores: the page URL, the media type, the verdict, the confidence score,
and the technical analysis details, for each scan you run. We do not
require or collect an account, name, or email address, and we do not
knowingly collect content from third parties who haven't interacted with
the extension themselves.</p>

<h2>What we don't do</h2>
<p>We do not sell your data. We do not use scanned content for advertising.
We do not track your general browsing activity — only the specific
content you (or, if enabled, Auto-protect) submit for analysis is
processed.</p>

<h2>Third-party services</h2>
<p>By default, the misinformation pipeline checks claims only against a
local, offline fact-check corpus bundled with the server — nothing is sent
to a third party. If the server operator has explicitly configured a live
retrieval provider (Google Fact Check Tools, NewsAPI, or Bing), the
extracted claim text may also be sent to that provider to retrieve
supporting sources; this is disclosed via the server's own configuration
and is off by default.</p>

<h2>Data retention and deletion</h2>
<p>Scan history is retained on the backend server until you clear it or
contact the developer to request deletion. Cached analysis results expire
automatically after 7 days.</p>

<h2>Contact</h2>
<p>Questions about this policy or a data-deletion request can be sent to
<a href="mailto:sofhia.egardoce@gmail.com">sofhia.egardoce@gmail.com</a>.</p>
</body>
</html>"""


@bp.get("/privacy")
def privacy_policy():
    return Response(PRIVACY_POLICY_HTML, mimetype="text/html")
