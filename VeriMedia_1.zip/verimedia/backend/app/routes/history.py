"""History + analytics routes powering the dashboard (Figures 3-6, 3-7)."""
from __future__ import annotations

from flask import Blueprint, jsonify, request

from .. import db

bp = Blueprint("history", __name__, url_prefix="/api/v1")


@bp.get("/history")
def history():
    limit = min(int(request.args.get("limit", 50)), 200)
    offset = max(int(request.args.get("offset", 0)), 0)
    media_type = request.args.get("media_type") or None
    items = db.list_analyses(limit=limit, offset=offset, media_type=media_type)
    return jsonify(items=items, total=db.count_analyses(), limit=limit, offset=offset), 200


@bp.get("/analytics/overview")
def analytics_overview():
    return jsonify(db.analytics_overview()), 200
