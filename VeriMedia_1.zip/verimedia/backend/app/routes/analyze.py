"""
API Gateway routes for the two verification pipelines
(POST /api/v1/analyze/image, /video, /text) plus async job polling.
"""
from __future__ import annotations

import os
import tempfile
import uuid

from flask import Blueprint, jsonify, request

from .. import db
from ..cache import get_or_compute
from ..config import config
from ..pipelines import deepfake, misinformation
from ..queue import submit as queue_submit
from ..utils import hash_bytes, hash_text, load_image_from_bytes

bp = Blueprint("analyze", __name__, url_prefix="/api/v1")

MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_VIDEO_BYTES = 150 * 1024 * 1024


@bp.post("/analyze/image")
def analyze_image():
    file = request.files.get("file")
    if file is None:
        return jsonify(error="Missing 'file' field (multipart/form-data image upload)."), 400

    data = file.read()
    if not data:
        return jsonify(error="Uploaded file is empty."), 400
    if len(data) > MAX_IMAGE_BYTES:
        return jsonify(error=f"Image exceeds max size of {MAX_IMAGE_BYTES} bytes."), 413

    try:
        pil_img = load_image_from_bytes(data)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400

    source_url = request.form.get("source_url", "")
    content_hash = hash_bytes(data)
    cache_key = f"image:{content_hash}"

    def compute():
        return deepfake.analyze_image(pil_img)

    result, cached = get_or_compute(cache_key, compute)
    result["cached"] = cached
    result["source_url"] = source_url

    record = db.insert_analysis(
        media_type="image", source_url=source_url or None, content_hash=content_hash,
        verdict=result["verdict"], confidence=result["confidence"],
        summary=_image_summary(result), details=result, engine=result["engine"],
    )
    result["analysis_id"] = record["id"]
    result["created_at"] = record["created_at"]
    return jsonify(result), 200


@bp.post("/analyze/video")
def analyze_video():
    file = request.files.get("file")
    source_url = request.form.get("source_url", "")
    run_async = request.form.get("async", "false").lower() == "true"

    if file is None:
        return jsonify(error="Missing 'file' field (multipart/form-data video upload)."), 400

    data = file.read()
    if not data:
        return jsonify(error="Uploaded file is empty."), 400
    if len(data) > MAX_VIDEO_BYTES:
        return jsonify(error=f"Video exceeds max size of {MAX_VIDEO_BYTES} bytes."), 413

    content_hash = hash_bytes(data)
    cache_key = f"video:{content_hash}"
    cached_result = db.cache_get(cache_key)
    if cached_result is not None:
        cached_result["cached"] = True
        cached_result["source_url"] = source_url
        record = db.insert_analysis(
            media_type="video", source_url=source_url or None, content_hash=content_hash,
            verdict=cached_result["verdict"], confidence=cached_result["confidence"],
            summary=_video_summary(cached_result), details=cached_result, engine=cached_result["engine"],
        )
        cached_result["analysis_id"] = record["id"]
        return jsonify(cached_result), 200

    suffix = os.path.splitext(file.filename or "")[1] or ".mp4"
    fd, tmp_path = tempfile.mkstemp(suffix=suffix, dir=str(config.DATA_DIR))
    with os.fdopen(fd, "wb") as f:
        f.write(data)

    def compute_and_store() -> dict:
        try:
            result = deepfake.analyze_video(tmp_path)
        finally:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        db.cache_set(cache_key, result, config.CACHE_TTL_SECONDS)
        result["cached"] = False
        result["source_url"] = source_url
        record = db.insert_analysis(
            media_type="video", source_url=source_url or None, content_hash=content_hash,
            verdict=result["verdict"], confidence=result["confidence"],
            summary=_video_summary(result), details=result, engine=result["engine"],
        )
        result["analysis_id"] = record["id"]
        return result

    if run_async:
        job_id = str(uuid.uuid4())
        db.create_job(job_id, "video")
        queue_submit(job_id, "video", compute_and_store)
        return jsonify(job_id=job_id, status="queued"), 202

    try:
        result = compute_and_store()
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    return jsonify(result), 200


@bp.get("/jobs/<job_id>")
def get_job(job_id: str):
    job = db.get_job(job_id)
    if job is None:
        return jsonify(error="Unknown job id."), 404
    return jsonify(job), 200


@bp.post("/analyze/text")
def analyze_text():
    payload = request.get_json(silent=True) or {}
    text = (payload.get("text") or request.form.get("text") or "").strip()
    source_url = payload.get("source_url") or request.form.get("source_url", "")

    if not text:
        return jsonify(error="Missing 'text' field."), 400
    if len(text) > 20000:
        text = text[:20000]

    content_hash = hash_text(text)
    cache_key = f"text:{content_hash}"

    def compute():
        return misinformation.classify_claim(text)

    result, cached = get_or_compute(cache_key, compute)
    result["cached"] = cached
    result["source_url"] = source_url
    result["input_text"] = text if len(text) <= 500 else text[:500] + "…"

    record = db.insert_analysis(
        media_type="text", source_url=source_url or None, content_hash=content_hash,
        verdict=result["verdict"], confidence=result["confidence"],
        summary=result["summary"], details=result, engine=result["engine"],
    )
    result["analysis_id"] = record["id"]
    result["created_at"] = record["created_at"]
    return jsonify(result), 200


def _image_summary(result: dict) -> str:
    verdict = result["verdict"]
    conf = round(result["confidence"] * 100)
    if verdict == "fake":
        return f"Flagged as likely manipulated media with {conf}% confidence."
    if verdict == "suspicious":
        return f"Flagged as suspicious with {conf}% confidence — manual review advised."
    return f"No strong manipulation signals detected ({conf}% manipulation confidence)."


def _video_summary(result: dict) -> str:
    verdict = result["verdict"]
    conf = round(result["confidence"] * 100)
    if verdict == "fake":
        return f"Flagged as likely deepfake video with {conf}% confidence across {result.get('frames_sampled', 0)} sampled frames."
    if verdict == "suspicious":
        return f"Flagged as suspicious with {conf}% confidence — manual review advised."
    return f"No strong manipulation signals detected across {result.get('frames_sampled', 0)} sampled frames ({conf}% confidence)."
