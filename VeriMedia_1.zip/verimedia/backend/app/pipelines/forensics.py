"""
Offline forensic signal engine.

Every function here computes a *real, deterministic signal* from the actual
pixel data — nothing is randomly generated or scripted to "look right". The
techniques are established digital-image-forensics methods that predate (and
still complement) deep-learning deepfake detectors, chosen specifically
because they need no pretrained weights and no internet access:

  * Error Level Analysis (ELA)          — JPEG re-compression residual;
                                           flags spliced/blended regions.
  * FFT spectral anomaly analysis        — GAN/upsampling decoders leave a
                                           characteristic periodic signature
                                           in the frequency domain (Durall et
                                           al., 2020; Zhang et al., 2019).
  * Noise-residual consistency           — face-swapped/composited regions
                                           usually have a different noise
                                           floor than the region they were
                                           pasted into.
  * Illumination-direction consistency   — mismatched lighting between a
                                           synthesized face and its
                                           background is a classic
                                           deepfake tell.
  * Haar-cascade face/eye geometry       — face localisation for the above,
                                           plus eye-detection sequences used
                                           for blink-based temporal analysis
                                           on video.

`app/pipelines/model_backend.py` documents how to replace/augment this
engine with a trained EfficientNet-GRU checkpoint once one is available.
"""
from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# Face / eye detectors (Haar cascades bundled with opencv-python — fully
# offline, no download required).
# ---------------------------------------------------------------------------
_FACE_CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
_EYE_CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")

BBox = tuple[int, int, int, int]  # x, y, w, h


def detect_faces(bgr: np.ndarray) -> list[BBox]:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    faces = _FACE_CASCADE.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(48, 48))
    return [tuple(int(v) for v in f) for f in faces]


def detect_eyes(bgr: np.ndarray, face_bbox: BBox) -> list[BBox]:
    x, y, w, h = face_bbox
    roi_gray = cv2.cvtColor(bgr[y : y + h, x : x + w], cv2.COLOR_BGR2GRAY)
    eyes = _EYE_CASCADE.detectMultiScale(roi_gray, scaleFactor=1.1, minNeighbors=6, minSize=(12, 12))
    return [tuple(int(v) for v in e) for e in eyes]


def largest_face(bgr: np.ndarray) -> Optional[BBox]:
    faces = detect_faces(bgr)
    if not faces:
        return None
    return max(faces, key=lambda f: f[2] * f[3])


# ---------------------------------------------------------------------------
# Error Level Analysis
# ---------------------------------------------------------------------------

def error_level_analysis(pil_img: Image.Image, quality: int = 90) -> dict:
    buf = io.BytesIO()
    pil_img.convert("RGB").save(buf, "JPEG", quality=quality)
    buf.seek(0)
    resaved = Image.open(buf).convert("RGB")

    orig = np.asarray(pil_img.convert("RGB"), dtype=np.int16)
    resv = np.asarray(resaved, dtype=np.int16)
    if orig.shape != resv.shape:
        resv = np.asarray(resaved.resize(pil_img.size), dtype=np.int16)

    diff = np.abs(orig - resv).astype(np.float32)
    ela_gray = diff.mean(axis=2)

    mean_level = float(ela_gray.mean())
    std_level = float(ela_gray.std())

    # Hotspot concentration: what fraction of "high error" pixels sit inside
    # a small contiguous area vs. spread evenly (uniform recompression noise
    # is normal; a tight hotspot suggests a locally blended/spliced region).
    threshold = mean_level + 2 * std_level if std_level > 0 else mean_level + 1
    hotspot_mask = ela_gray > max(threshold, 8.0)
    hotspot_ratio = float(hotspot_mask.mean())

    concentration = 0.0
    if hotspot_mask.any():
        ys, xs = np.nonzero(hotspot_mask)
        bbox_area = (ys.max() - ys.min() + 1) * (xs.max() - xs.min() + 1)
        concentration = float(hotspot_mask.sum() / max(bbox_area, 1))

    return {
        "mean_error_level": round(mean_level, 3),
        "error_std": round(std_level, 3),
        "hotspot_ratio": round(hotspot_ratio, 4),
        "hotspot_concentration": round(concentration, 4),
    }


# ---------------------------------------------------------------------------
# FFT spectral anomaly analysis
# ---------------------------------------------------------------------------

def _radial_profile(power: np.ndarray, n_bins: int = 40) -> np.ndarray:
    h, w = power.shape
    cy, cx = h / 2, w / 2
    y, x = np.indices((h, w))
    r = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    r_norm = (r / r.max() * (n_bins - 1)).astype(np.int32)
    profile = np.zeros(n_bins, dtype=np.float64)
    counts = np.zeros(n_bins, dtype=np.float64)
    np.add.at(profile, r_norm.ravel(), power.ravel())
    np.add.at(counts, r_norm.ravel(), 1)
    counts[counts == 0] = 1
    return profile / counts


def spectral_anomaly(gray: np.ndarray) -> dict:
    # Work on a fixed size so the radial profile is comparable across images.
    resized = cv2.resize(gray, (256, 256), interpolation=cv2.INTER_AREA).astype(np.float32)
    resized = resized - resized.mean()
    window = np.outer(np.hanning(256), np.hanning(256))
    f = np.fft.fftshift(np.fft.fft2(resized * window))
    power = np.log1p(np.abs(f) ** 2)

    profile = _radial_profile(power)
    # Natural photographic images have a roughly monotonic-decaying radial
    # spectrum (1/f-ish falloff). Fit a line in log-log-ish space (profile is
    # already log-power) and measure how much energy sits *above* that fit in
    # the mid/high frequency bands — GAN decoders leave excess, often
    # periodic, high-frequency energy there.
    mid_high = profile[len(profile) // 3 :]
    idx = np.arange(len(mid_high))
    if len(idx) > 2 and mid_high.std() > 1e-6:
        coeffs = np.polyfit(idx, mid_high, 1)
        fit = np.polyval(coeffs, idx)
        residual = mid_high - fit
        anomaly = float(np.clip(residual[residual > 0].sum() / (np.abs(mid_high).sum() + 1e-6), 0, 1))
    else:
        anomaly = 0.0

    # Periodicity: look for a sharp, *isolated* peak in the autocorrelation
    # of the high-frequency band (checkerboard/up-convolution artifacts
    # recur at a regular spatial period, producing a narrow off-center
    # spike). A broad smooth lobe near the center — which any low-frequency-
    # dominated natural image will have — is excluded by using a wide
    # exclusion radius and scoring the peak's *prominence* over its local
    # background rather than its raw height.
    high_band = power[64:192, 64:192]
    high_band = high_band - high_band.mean()
    autocorr = np.fft.ifft2(np.abs(np.fft.fft2(high_band)) ** 2).real
    autocorr = np.fft.fftshift(autocorr)
    autocorr /= autocorr.max() + 1e-6
    center = autocorr.shape[0] // 2
    exclusion = autocorr.shape[0] // 6  # exclude the broad central/DC lobe
    ring = autocorr.copy()
    ring[center - exclusion : center + exclusion + 1, center - exclusion : center + exclusion + 1] = np.nan
    outside = ring[~np.isnan(ring)]
    if outside.size:
        # Bounded headroom score: how much of the space *above* the ring's
        # typical (95th-percentile) level does the single strongest peak
        # occupy? A broad lobe (smooth/low-frequency images) keeps the 95th
        # percentile close to the peak (little headroom -> low score); a
        # genuinely isolated periodic spike (checkerboard/up-conv artifacts)
        # leaves most of the ring far below the peak (lots of headroom ->
        # high score). Using a percentile instead of std keeps this stable
        # even when the ring is nearly flat (pure noise).
        p95 = float(np.percentile(outside, 95))
        peak = float(np.nanmax(ring))
        periodicity_score = float(np.clip((peak - p95) / max(1.0 - p95, 1e-3), 0, 1))
    else:
        periodicity_score = 0.0

    return {
        "spectral_anomaly": round(anomaly, 4),
        "periodicity_score": round(periodicity_score, 4),
    }


# ---------------------------------------------------------------------------
# Noise-residual consistency
# ---------------------------------------------------------------------------

def _laplacian_noise_energy(gray_region: np.ndarray) -> float:
    if gray_region.size == 0:
        return 0.0
    lap = cv2.Laplacian(gray_region, cv2.CV_64F)
    return float(lap.var())


def noise_consistency(bgr: np.ndarray, face_bbox: Optional[BBox]) -> dict:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    global_noise = _laplacian_noise_energy(gray)

    if face_bbox is None:
        return {
            "global_noise_energy": round(global_noise, 2),
            "face_noise_energy": None,
            "background_noise_energy": None,
            "noise_ratio_anomaly": 0.0,
        }

    x, y, w, h = face_bbox
    face_region = gray[y : y + h, x : x + w]
    mask = np.ones_like(gray, dtype=bool)
    mask[y : y + h, x : x + w] = False
    bg_region = gray[mask]

    face_noise = _laplacian_noise_energy(face_region)
    bg_noise = float(cv2.Laplacian(gray, cv2.CV_64F)[mask].var()) if bg_region.size else 0.0

    ratio = 0.0
    if bg_noise > 1e-6:
        r = face_noise / bg_noise
        # Anomaly grows the further the face/background noise ratio departs
        # from ~1.0 (consistent capture) in either direction.
        ratio = float(np.clip(abs(np.log(max(r, 1e-6))) / np.log(6), 0, 1))

    return {
        "global_noise_energy": round(global_noise, 2),
        "face_noise_energy": round(face_noise, 2),
        "background_noise_energy": round(bg_noise, 2),
        "noise_ratio_anomaly": round(ratio, 4),
    }


# ---------------------------------------------------------------------------
# Illumination-direction consistency between face and surrounding scene
# ---------------------------------------------------------------------------

def illumination_consistency(bgr: np.ndarray, face_bbox: Optional[BBox]) -> dict:
    if face_bbox is None:
        return {"illumination_anomaly": 0.0}

    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    x, y, w, h = face_bbox
    face = gray[y : y + h, x : x + w]
    if face.size == 0:
        return {"illumination_anomaly": 0.0}

    gx = cv2.Sobel(face, cv2.CV_32F, 1, 0, ksize=5)
    gy = cv2.Sobel(face, cv2.CV_32F, 0, 1, ksize=5)
    face_gradient_dir = float(np.arctan2(gy.mean(), gx.mean()))

    pad = int(max(w, h) * 0.6)
    y0, y1 = max(0, y - pad), min(gray.shape[0], y + h + pad)
    x0, x1 = max(0, x - pad), min(gray.shape[1], x + w + pad)
    context = gray[y0:y1, x0:x1].copy()
    context[y - y0 : y - y0 + h, x - x0 : x - x0 + w] = np.nan  # exclude the face itself
    valid = context[~np.isnan(context)]
    if valid.size < 25:
        return {"illumination_anomaly": 0.0}

    cgx = cv2.Sobel(np.nan_to_num(context, nan=float(np.nanmean(context))), cv2.CV_32F, 1, 0, ksize=5)
    cgy = cv2.Sobel(np.nan_to_num(context, nan=float(np.nanmean(context))), cv2.CV_32F, 0, 1, ksize=5)
    ctx_gradient_dir = float(np.arctan2(cgy.mean(), cgx.mean()))

    angle_diff = abs(face_gradient_dir - ctx_gradient_dir)
    angle_diff = min(angle_diff, 2 * np.pi - angle_diff)
    anomaly = float(np.clip(angle_diff / np.pi, 0, 1))

    return {"illumination_anomaly": round(anomaly, 4)}


# ---------------------------------------------------------------------------
# Composite scoring
# ---------------------------------------------------------------------------

# Documented, transparent weights for the composite manipulation score.
# These are a deliberately interpretable rule-based baseline (common in the
# forensics literature prior to/alongside deep detectors) — swap in a
# trained classifier's output via app/pipelines/model_backend.py and it
# takes priority automatically (see combine_with_model_backend()).
WEIGHTS = {
    "ela_hotspot": 0.28,
    "spectral_anomaly": 0.24,
    "periodicity": 0.14,
    "noise_ratio": 0.18,
    "illumination": 0.16,
}


@dataclass
class FrameForensics:
    ela: dict
    spectral: dict
    noise: dict
    illumination: dict
    face_bbox: Optional[BBox]
    eyes_detected: int
    composite_score: float = 0.0
    anomalies: list[str] = field(default_factory=list)


def analyze_frame(bgr: np.ndarray, pil_img: Optional[Image.Image] = None) -> FrameForensics:
    if pil_img is None:
        pil_img = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    face_bbox = largest_face(bgr)
    eyes = detect_eyes(bgr, face_bbox) if face_bbox else []

    ela = error_level_analysis(pil_img)
    spectral = spectral_anomaly(gray)
    noise = noise_consistency(bgr, face_bbox)
    illum = illumination_consistency(bgr, face_bbox)

    ela_component = min(ela["hotspot_ratio"] * 4 + ela["hotspot_concentration"] * 0.6, 1.0)
    score = (
        WEIGHTS["ela_hotspot"] * ela_component
        + WEIGHTS["spectral_anomaly"] * spectral["spectral_anomaly"]
        + WEIGHTS["periodicity"] * spectral["periodicity_score"]
        + WEIGHTS["noise_ratio"] * noise["noise_ratio_anomaly"]
        + WEIGHTS["illumination"] * illum["illumination_anomaly"]
    )
    score = float(np.clip(score, 0.0, 1.0))

    anomalies = []
    if ela["hotspot_ratio"] > 0.05:
        anomalies.append("Localized JPEG error-level hotspot consistent with blended/composited region")
    if spectral["spectral_anomaly"] > 0.3:
        anomalies.append("Anomalous high-frequency spectral energy consistent with GAN upsampling artifacts")
    if spectral["periodicity_score"] > 0.35:
        anomalies.append("Periodic frequency-domain pattern consistent with synthetic generation")
    if noise["noise_ratio_anomaly"] > 0.4:
        anomalies.append("Noise-level mismatch between face region and background")
    if illum["illumination_anomaly"] > 0.4:
        anomalies.append("Lighting-direction inconsistency between face and surrounding scene")

    return FrameForensics(
        ela=ela, spectral=spectral, noise=noise, illumination=illum,
        face_bbox=face_bbox, eyes_detected=len(eyes),
        composite_score=round(score, 4), anomalies=anomalies,
    )
