"""
Deepfake detection pipeline — Pipeline A in the thesis's system architecture
(Figure 3-13): "EfficientNet, GRU, Photo/Video".

Two media types are handled:

  * Image  -> single-frame forensic analysis (spatial signals only, mirroring
              the thesis's "EfficientNet extracts spatial features").
  * Video  -> per-frame forensic analysis over sampled frames PLUS a
              temporal-consistency stage (mirroring "GRU analyzes temporal
              patterns and inconsistencies across video sequences").

If a trained ONNX model is configured (see model_backend.py) its prediction
is blended with the forensic-engine score (weighted average, model given
more trust) rather than replacing it outright — this keeps the system
robust even if the trained model is confidently wrong on an out-of-domain
sample, and is a defensible design choice to describe in your defense.
"""
from __future__ import annotations

import time
from typing import Optional

import cv2
import numpy as np
from PIL import Image

from ..config import config
from ..utils import verdict_from_score
from . import forensics
from .model_backend import get_model_backend


def analyze_image(pil_img: Image.Image) -> dict:
    t0 = time.time()
    bgr = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)
    frame_result = forensics.analyze_frame(bgr, pil_img)

    score = frame_result.composite_score
    model_used = False
    model_score: Optional[float] = None

    backend = get_model_backend()
    if backend.available:
        try:
            model_score = backend.image_classifier.predict_proba(np.array(pil_img.convert("RGB")))
            score = float(np.clip(0.7 * model_score + 0.3 * frame_result.composite_score, 0, 1))
            model_used = True
        except Exception:  # noqa: BLE001
            pass  # heuristic score stands

    verdict = verdict_from_score(score, config.DEEPFAKE_FLAG_THRESHOLD, config.DEEPFAKE_SUSPICIOUS_THRESHOLD)

    return {
        "media_type": "image",
        "verdict": verdict,
        "confidence": round(score, 4),
        "processing_time_ms": round((time.time() - t0) * 1000, 1),
        "engine": "onnx_model+forensics" if model_used else "forensics_heuristic",
        "model_score": model_score,
        "face_detected": frame_result.face_bbox is not None,
        "anomalies": frame_result.anomalies,
        "signals": {
            "error_level_analysis": frame_result.ela,
            "spectral_analysis": frame_result.spectral,
            "noise_consistency": frame_result.noise,
            "illumination_consistency": frame_result.illumination,
        },
    }


def _sample_frame_indices(total_frames: int, max_frames: int) -> list[int]:
    if total_frames <= max_frames:
        return list(range(total_frames))
    step = total_frames / max_frames
    return [int(i * step) for i in range(max_frames)]


def analyze_video(video_path: str) -> dict:
    t0 = time.time()
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError("Could not open video file")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    indices = _sample_frame_indices(max(total_frames, 1), config.VIDEO_MAX_FRAMES)

    frame_scores: list[float] = []
    face_centers: list[tuple[float, float]] = []
    face_sizes: list[float] = []
    eye_counts: list[int] = []
    all_anomalies: set[str] = set()
    per_frame_feats: list[np.ndarray] = []

    idx_set = set(indices)
    current = 0
    read_ok, frame = cap.read()
    while read_ok:
        if current in idx_set:
            result = forensics.analyze_frame(frame)
            frame_scores.append(result.composite_score)
            all_anomalies.update(result.anomalies)
            eye_counts.append(result.eyes_detected)
            if result.face_bbox:
                x, y, w, h = result.face_bbox
                face_centers.append((x + w / 2, y + h / 2))
                face_sizes.append(float(max(w, h)))
            per_frame_feats.append(np.array([
                result.ela["hotspot_ratio"], result.spectral["spectral_anomaly"],
                result.spectral["periodicity_score"], result.noise["noise_ratio_anomaly"],
                result.illumination["illumination_anomaly"],
            ], dtype=np.float32))
        current += 1
        read_ok, frame = cap.read()
    cap.release()

    if not frame_scores:
        raise ValueError("No frames could be decoded from the uploaded video")

    frame_scores_arr = np.array(frame_scores)
    mean_spatial_score = float(frame_scores_arr.mean())
    temporal_variance = float(frame_scores_arr.std())

    # Frame-to-frame face jitter, normalised by face size — a proxy for the
    # unnatural micro-movement / warping that face-swap deepfakes exhibit
    # frame to frame (this is precisely the class of signal a trained GRU
    # over per-frame embeddings would learn to weight).
    jitter_score = 0.0
    if len(face_centers) >= 3:
        centers = np.array(face_centers)
        deltas = np.linalg.norm(np.diff(centers, axis=0), axis=1)
        avg_size = float(np.mean(face_sizes)) or 1.0
        jitter_score = float(np.clip(deltas.std() / avg_size * 4, 0, 1))

    # Blink-pattern plausibility: real human video sampled over a handful of
    # frames should show *some* variation in eye-detection count (open vs.
    # closed/blinking); a perfectly constant eye count across all sampled
    # frames of a face-containing video is mildly anomalous for GAN-rendered
    # faces, which often under-render blinking.
    blink_anomaly = 0.0
    face_frame_eye_counts = [c for c, center in zip(eye_counts, face_centers)]
    if len(face_frame_eye_counts) >= 4:
        variety = len(set(face_frame_eye_counts))
        blink_anomaly = 0.0 if variety > 1 else 0.35

    temporal_component = float(np.clip(temporal_variance * 3, 0, 1))

    combined_score = float(np.clip(
        0.55 * mean_spatial_score
        + 0.20 * temporal_component
        + 0.15 * jitter_score
        + 0.10 * blink_anomaly,
        0, 1,
    ))

    model_used = False
    model_score: Optional[float] = None
    backend = get_model_backend()
    if backend.temporal_gru is not None and per_frame_feats:
        try:
            model_score = backend.temporal_gru.forward(np.stack(per_frame_feats))
            combined_score = float(np.clip(0.7 * model_score + 0.3 * combined_score, 0, 1))
            model_used = True
        except Exception:  # noqa: BLE001
            pass

    verdict = verdict_from_score(combined_score, config.DEEPFAKE_FLAG_THRESHOLD, config.DEEPFAKE_SUSPICIOUS_THRESHOLD)

    anomalies = list(all_anomalies)
    if jitter_score > 0.4:
        anomalies.append("Unnatural frame-to-frame facial movement (temporal jitter)")
    if blink_anomaly > 0:
        anomalies.append("Constant eye state across sampled frames (blink pattern anomaly)")
    if temporal_component > 0.4:
        anomalies.append("High variance in per-frame manipulation signals across the sequence")

    return {
        "media_type": "video",
        "verdict": verdict,
        "confidence": round(combined_score, 4),
        "processing_time_ms": round((time.time() - t0) * 1000, 1),
        "engine": "onnx_gru+forensics" if model_used else "forensics_heuristic_temporal",
        "model_score": model_score,
        "frames_sampled": len(frame_scores),
        "total_frames": total_frames,
        "fps": round(fps, 2),
        "face_detected_ratio": round(len(face_centers) / max(len(frame_scores), 1), 3),
        "anomalies": anomalies,
        "signals": {
            "mean_spatial_score": round(mean_spatial_score, 4),
            "temporal_variance": round(temporal_variance, 4),
            "facial_jitter_score": round(jitter_score, 4),
            "blink_anomaly_score": round(blink_anomaly, 4),
        },
    }
