"""
Pluggable live-retrieval backend for the misinformation pipeline.

By default (no API key configured) the system retrieves against the local
curated corpus in `corpus.json` — genuine TF-IDF retrieval, fully offline.
This module is the drop-in slot for retrieving against the live web once
the backend is deployed somewhere with normal internet access, matching the
thesis's "retrieves relevant information from reliable sources" step.

To enable, set in backend/.env:
    VERIMEDIA_RETRIEVAL_PROVIDER=google_fact_check   # or "bing" or "newsapi"
    VERIMEDIA_RETRIEVAL_API_KEY=<your key>

These providers are implemented against their real, documented public APIs
using `requests` (already a core dependency) — they are functional code,
just untestable inside this sandbox's restricted network. Any provider that
fails (network error, bad key, quota) is caught and the pipeline silently
falls back to the local corpus, so production deployments degrade
gracefully instead of erroring out.
"""
from __future__ import annotations

import logging
from typing import Optional

import requests

from ..config import config

log = logging.getLogger(__name__)

TIMEOUT_S = 6


class RetrievedDocument:
    def __init__(self, text: str, source: str, url: str = ""):
        self.text = text
        self.source = source
        self.url = url

    def to_dict(self) -> dict:
        return {"text": self.text, "source": self.source, "url": self.url}


def _google_fact_check(claim: str, api_key: str) -> list[RetrievedDocument]:
    resp = requests.get(
        "https://factchecktools.googleapis.com/v1alpha1/claims:search",
        params={"query": claim, "key": api_key, "languageCode": "en"},
        timeout=TIMEOUT_S,
    )
    resp.raise_for_status()
    data = resp.json()
    docs = []
    for c in data.get("claims", [])[:5]:
        for review in c.get("claimReview", []):
            text = f"{c.get('text', claim)} — rated '{review.get('textualRating', 'unknown')}' by {review.get('publisher', {}).get('name', 'a fact-checker')}"
            docs.append(RetrievedDocument(text=text, source=review.get("publisher", {}).get("name", "fact-checker"), url=review.get("url", "")))
    return docs


def _newsapi(claim: str, api_key: str) -> list[RetrievedDocument]:
    resp = requests.get(
        "https://newsapi.org/v2/everything",
        params={"q": claim, "apiKey": api_key, "pageSize": 5, "sortBy": "relevancy"},
        timeout=TIMEOUT_S,
    )
    resp.raise_for_status()
    data = resp.json()
    docs = []
    for a in data.get("articles", [])[:5]:
        text = f"{a.get('title', '')} — {a.get('description', '')}"
        docs.append(RetrievedDocument(text=text, source=a.get("source", {}).get("name", "news"), url=a.get("url", "")))
    return docs


def _bing_search(claim: str, api_key: str) -> list[RetrievedDocument]:
    resp = requests.get(
        "https://api.bing.microsoft.com/v7.0/search",
        params={"q": claim, "count": 5},
        headers={"Ocp-Apim-Subscription-Key": api_key},
        timeout=TIMEOUT_S,
    )
    resp.raise_for_status()
    data = resp.json()
    docs = []
    for item in data.get("webPages", {}).get("value", [])[:5]:
        text = f"{item.get('name', '')} — {item.get('snippet', '')}"
        docs.append(RetrievedDocument(text=text, source=item.get("displayUrl", "web"), url=item.get("url", "")))
    return docs


_PROVIDERS = {
    "google_fact_check": _google_fact_check,
    "newsapi": _newsapi,
    "bing": _bing_search,
}


def retrieve_live(claim: str) -> Optional[list[RetrievedDocument]]:
    """Returns None if live retrieval isn't configured or fails, so callers
    can fall back to the local corpus."""
    provider = config.LIVE_RETRIEVAL_PROVIDER
    api_key = config.LIVE_RETRIEVAL_API_KEY
    if not provider or not api_key:
        return None
    fn = _PROVIDERS.get(provider)
    if fn is None:
        log.warning("Unknown VERIMEDIA_RETRIEVAL_PROVIDER=%s", provider)
        return None
    try:
        docs = fn(claim, api_key)
        return docs or None
    except Exception:  # noqa: BLE001
        log.exception("Live retrieval via %s failed; falling back to local corpus", provider)
        return None
