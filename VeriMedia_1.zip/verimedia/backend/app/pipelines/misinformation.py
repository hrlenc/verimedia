"""
Misinformation detection pipeline — Pipeline B in the thesis's system
architecture (Figure 3-13): "Query Generator, Knowledge Retrieve, NLP
Classifier".

Stages, each a genuine, offline-computable NLP technique:

  1. Claim extraction  — TextRank-style extractive summarisation (Mihalcea &
     Tarau, 2004): sentences are embedded as TF-IDF vectors, a cosine-
     similarity graph is built between them, and PageRank picks the most
     "central" sentence as the core claim to fact-check. `networkx` and
     `scikit-learn` are already core dependencies.
  2. Retrieval          — TF-IDF vectorisation + cosine similarity against
     `corpus.json` (a curated fact-check knowledge base), OR against live
     documents from `retrieval_backend.py` when a provider/API key is
     configured. This *is* the "semantic consistency" comparison the thesis
     describes — cosine similarity between the claim and each candidate
     document is a real, well-established semantic-similarity measure, just
     computed over TF-IDF space rather than transformer embeddings (see
     requirements-production.txt for a `sentence-transformers` upgrade
     path that keeps this exact call signature).
  3. Classification     — weighted vote of the top-k retrieved documents'
     labels (true / false / misleading), plus transparent stylistic
     signals (sensational punctuation/phrasing) that are known correlates
     of low-credibility content in the misinformation-detection literature.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Optional

import networkx as nx
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ..config import config
from . import retrieval_backend

_CORPUS_PATH = Path(__file__).parent / "corpus.json"
with open(_CORPUS_PATH, "r", encoding="utf-8") as f:
    _CORPUS: list[dict] = json.load(f)

_CORPUS_TEXTS = [f"{c['claim']} {c['explanation']}" for c in _CORPUS]
_CORPUS_VECTORIZER = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), min_df=1)
_CORPUS_MATRIX = _CORPUS_VECTORIZER.fit_transform(_CORPUS_TEXTS)

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_SENSATIONAL_PHRASES = [
    "share before it's deleted", "you won't believe", "doctors hate", "shocking truth",
    "wake up", "they don't want you to know", "mainstream media won't tell you",
    "forward this to everyone", "act now", "urgent warning", "miracle cure",
]


_INTERJECTION_RE = re.compile(
    r"^(breaking|urgent|warning|wow|omg|alert|share|attention|watch|look)\b", re.IGNORECASE
)


def _informativeness(sentence: str) -> float:
    """Cheap, corpus-independent proxy for 'this sentence carries a
    checkable factual claim' rather than framing/interjection filler:
    rewards length and digit/proper-noun density, penalises short
    clickbait-style lead-ins ('BREAKING:', 'Share this...')."""
    words = sentence.split()
    n = len(words)
    if n == 0:
        return 0.0
    digit_or_capitalized = sum(1 for w in words[1:] if any(c.isdigit() for c in w) or (w[:1].isupper() and w.lower() not in _SENSATIONAL_PHRASES))
    length_score = min(n / 12.0, 1.0)
    density_score = digit_or_capitalized / max(n - 1, 1)
    penalty = 0.5 if _INTERJECTION_RE.match(sentence.strip()) else 0.0
    return max(0.0, 0.6 * length_score + 0.4 * density_score - penalty)


def rank_candidate_claims(text: str, top_n: int = 3) -> list[str]:
    """Rank sentences by a blend of TextRank centrality (via TF-IDF cosine
    graph + PageRank, Mihalcea & Tarau 2004) and an informativeness proxy,
    so that framing/interjection sentences ('BREAKING:', 'Share this!!!')
    are not preferred over the substantive claim just because they happen
    to sit in a short, topically disjoint message. Returns up to `top_n`
    candidate sentences, most-likely-claim first."""
    text = text.strip()
    sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if len(s.strip()) > 8]
    if len(sentences) <= 1:
        return [text[:500]] if text else [""]

    centrality = {i: 0.0 for i in range(len(sentences))}
    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        matrix = vectorizer.fit_transform(sentences)
        sim_matrix = cosine_similarity(matrix)
        np.fill_diagonal(sim_matrix, 0)
        if sim_matrix.sum() > 0:
            graph = nx.from_numpy_array(sim_matrix)
            centrality = nx.pagerank(graph, max_iter=200)
    except (ValueError, nx.PowerIterationFailedConvergence):
        pass

    scored = sorted(
        range(len(sentences)),
        key=lambda i: 0.5 * centrality.get(i, 0.0) + 0.5 * _informativeness(sentences[i]),
        reverse=True,
    )
    return [sentences[i] for i in scored[:top_n]]


def extract_claim(text: str) -> str:
    """Single best candidate (used for display/logging)."""
    candidates = rank_candidate_claims(text, top_n=1)
    return candidates[0] if candidates else text[:500]


def _stylistic_signals(text: str) -> dict:
    lower = text.lower()
    exclamations = text.count("!")
    caps_words = sum(1 for w in re.findall(r"\b[A-Za-z]{3,}\b", text) if w.isupper())
    total_words = max(len(text.split()), 1)
    sensational_hits = [p for p in _SENSATIONAL_PHRASES if p in lower]

    sensationalism = float(np.clip(
        exclamations * 0.06 + (caps_words / total_words) * 0.8 + len(sensational_hits) * 0.2, 0, 1
    ))
    return {
        "exclamation_count": exclamations,
        "all_caps_word_ratio": round(caps_words / total_words, 4),
        "sensational_phrases_found": sensational_hits,
        "sensationalism_score": round(sensationalism, 4),
    }


def _retrieve_local(claim: str, top_k: int) -> list[dict]:
    query_vec = _CORPUS_VECTORIZER.transform([claim])
    sims = cosine_similarity(query_vec, _CORPUS_MATRIX).flatten()
    top_idx = np.argsort(sims)[::-1][:top_k]
    results = []
    for i in top_idx:
        entry = _CORPUS[i]
        results.append({
            "similarity": round(float(sims[i]), 4),
            "claim": entry["claim"],
            "label": entry["label"],
            "explanation": entry["explanation"],
            "category": entry["category"],
            "source": "VeriMedia curated fact-check corpus",
        })
    return results


def _retrieve_and_score_live(claim: str, top_k: int) -> Optional[list[dict]]:
    docs = retrieval_backend.retrieve_live(claim)
    if not docs:
        return None
    texts = [d.text for d in docs]
    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        matrix = vectorizer.fit_transform(texts + [claim])
    except ValueError:
        return None
    sims = cosine_similarity(matrix[-1], matrix[:-1]).flatten()
    order = np.argsort(sims)[::-1][:top_k]
    results = []
    for i in order:
        results.append({
            "similarity": round(float(sims[i]), 4),
            "claim": docs[i].text,
            "label": "unverified",  # live web docs aren't pre-labeled; NLP classifier below infers stance from lexical overlap only
            "explanation": "Retrieved from live web source; label inferred from semantic overlap, not a pre-vetted fact-check database.",
            "category": "live_web",
            "source": docs[i].source,
            "url": docs[i].url,
        })
    return results


def classify_claim(text: str) -> dict:
    t0 = time.time()
    stylistic = _stylistic_signals(text)

    # Try each candidate claim sentence against the knowledge base and keep
    # whichever one actually retrieves the strongest match — this is more
    # robust than committing to a single "most central" sentence up front,
    # especially for short social-media posts that mix a factual claim with
    # clickbait framing ("BREAKING:", "Share before it's deleted!!!").
    candidates = rank_candidate_claims(text, top_n=3)
    best_claim, best_results, best_mode = candidates[0], [], "local_corpus"
    best_top_sim = -1.0
    for candidate in candidates:
        live_results = _retrieve_and_score_live(candidate, config.RETRIEVAL_TOP_K)
        mode = "live_web"
        results = live_results
        if results is None:
            mode = "local_corpus"
            results = _retrieve_local(candidate, config.RETRIEVAL_TOP_K)
        top_sim = results[0]["similarity"] if results else 0.0
        if top_sim > best_top_sim:
            best_claim, best_results, best_mode, best_top_sim = candidate, results, mode, top_sim

    claim, results, retrieval_mode = best_claim, best_results, best_mode

    if not results or results[0]["similarity"] < 0.12:
        verdict = "unverified"
        confidence = round(float(np.clip(0.5 + stylistic["sensationalism_score"] * 0.2, 0.5, 0.75)), 4)
        summary = "No sufficiently similar claim was found in the knowledge base to verify or refute this statement."
    else:
        label_weights: dict[str, float] = {}
        for r in results:
            label_weights[r["label"]] = label_weights.get(r["label"], 0.0) + r["similarity"]
        # drop "unverified" from the vote itself but keep it visible in results
        voting = {k: v for k, v in label_weights.items() if k != "unverified"}
        if not voting:
            verdict = "unverified"
            confidence = 0.55
            summary = "Related content was found, but it could not be confidently rated true or false."
        else:
            verdict = max(voting, key=voting.get)
            total = sum(voting.values())
            confidence = float(np.clip(voting[verdict] / total * results[0]["similarity"] / max(results[0]["similarity"], 1e-6), 0, 1))
            # confidence is primarily driven by the strength of the best match,
            # tempered by how much the vote agrees with it
            confidence = float(np.clip(0.5 * results[0]["similarity"] + 0.5 * (voting[verdict] / total), 0, 1))
            top = results[0]
            summary = top["explanation"]

    # Sensational phrasing nudges a borderline "true" toward "misleading" —
    # a stylistic red flag layered on top of the retrieval verdict, not a
    # replacement for it.
    if verdict == "true" and stylistic["sensationalism_score"] > 0.5:
        verdict = "misleading"
        summary = f"{summary} Additionally, the phrasing uses sensationalized language patterns often associated with misleading framing even when an underlying fact is present."

    return {
        "media_type": "text",
        "extracted_claim": claim,
        "verdict": verdict,
        "confidence": round(confidence, 4),
        "summary": summary,
        "processing_time_ms": round((time.time() - t0) * 1000, 1),
        "engine": f"retrieval_nlp:{retrieval_mode}",
        "retrieved_evidence": results,
        "signals": {"stylistic": stylistic},
    }
