"""
Pluggable deep-model backend for deepfake detection.

The thesis names EfficientNet (spatial features) + GRU (temporal features)
as the intended architecture. Training that model needs a labeled deepfake
dataset (e.g. FaceForensics++, DFDC, Celeb-DF) and GPU time that this
environment doesn't have. This module is the drop-in slot for it:

  1. Train/export your EfficientNet-GRU (or any CNN+RNN) model to ONNX.
     - For an image-only EfficientNet classifier: export with input shape
       (1, 3, 224, 224) and a single output logit/probability.
     - For the video EfficientNet-GRU: export a two-stage graph, or simply
       export the EfficientNet feature extractor to ONNX and keep the GRU's
       trained weights as a `.npz` (see `NumpyGRU` below) — both are loaded
       automatically if present.
  2. Set VERIMEDIA_ONNX_MODEL_PATH (backend/.env) to the .onnx file path.
  3. Restart the backend. `get_model_backend()` will pick it up; if the
     path is unset or the file/onnxruntime import fails, every pipeline
     silently falls back to the forensic heuristic engine
     (app/pipelines/forensics.py) — nothing breaks either way.

`onnxruntime` is already a core dependency, so once you have a trained
model file this path works with no further installs.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np

from ..config import config

log = logging.getLogger(__name__)


class OnnxImageClassifier:
    """Thin wrapper around an ONNX Runtime session for a frame-level
    deepfake classifier (e.g. a trained EfficientNet head)."""

    def __init__(self, model_path: str):
        import onnxruntime as ort  # local import: keep it optional

        self.session = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        input_shape = self.session.get_inputs()[0].shape
        # Expect NCHW; fall back to a sane default if the exporter left
        # dynamic axes.
        self.input_size = (224, 224)
        if len(input_shape) == 4 and isinstance(input_shape[2], int) and isinstance(input_shape[3], int):
            self.input_size = (input_shape[3], input_shape[2])

    def predict_proba(self, rgb_uint8: np.ndarray) -> float:
        import cv2

        resized = cv2.resize(rgb_uint8, self.input_size, interpolation=cv2.INTER_AREA)
        x = resized.astype(np.float32) / 255.0
        x = (x - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array(
            [0.229, 0.224, 0.225], dtype=np.float32
        )
        x = np.transpose(x, (2, 0, 1))[None, ...]  # NCHW
        outputs = self.session.run(None, {self.input_name: x})
        logits = np.asarray(outputs[0]).squeeze()
        if logits.ndim == 0:
            prob = 1 / (1 + np.exp(-logits))  # sigmoid, single-logit head
        else:
            exp = np.exp(logits - logits.max())
            softmax = exp / exp.sum()
            prob = softmax[-1]  # convention: last class = "fake"
        return float(np.clip(prob, 0.0, 1.0))


class NumpyGRU:
    """A from-scratch, numerically-correct GRU forward pass in NumPy.

    Loads trained weight matrices from a `.npz` file with keys
    `W_ir,W_iz,W_in,W_hr,W_hz,W_hn,b_ir,b_iz,b_in,b_hr,b_hz,b_hn,W_out,b_out`
    (the same layout PyTorch's `nn.GRU` + a linear head produce — see
    `scripts/export_gru_weights.py` for a conversion helper). Runs a
    per-frame feature sequence through the recurrence to produce a single
    temporal "fake probability" for a video, which is exactly the role the
    thesis assigns to the GRU stage.

    Without a trained `.npz`, this class is never instantiated — video
    temporal scoring uses the statistical consistency metrics in
    `deepfake.py` instead, which approximate the same goal (flagging
    frame-to-frame inconsistency) without requiring trained weights.
    """

    def __init__(self, weights_path: str):
        data = np.load(weights_path)
        self.w = {k: data[k] for k in data.files}
        self.hidden_size = self.w["W_hr"].shape[0]

    def _sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def forward(self, sequence: np.ndarray) -> float:
        h = np.zeros(self.hidden_size, dtype=np.float32)
        for x_t in sequence:
            r = self._sigmoid(self.w["W_ir"] @ x_t + self.w["b_ir"] + self.w["W_hr"] @ h + self.w["b_hr"])
            z = self._sigmoid(self.w["W_iz"] @ x_t + self.w["b_iz"] + self.w["W_hz"] @ h + self.w["b_hz"])
            n = np.tanh(self.w["W_in"] @ x_t + self.w["b_in"] + r * (self.w["W_hn"] @ h + self.w["b_hn"]))
            h = (1 - z) * n + z * h
        logit = self.w["W_out"] @ h + self.w["b_out"]
        return float(1 / (1 + np.exp(-logit)))


class ModelBackend:
    def __init__(self):
        self.image_classifier: Optional[OnnxImageClassifier] = None
        self.temporal_gru: Optional[NumpyGRU] = None
        self._load()

    def _load(self) -> None:
        path = config.ONNX_DEEPFAKE_MODEL_PATH
        if path and Path(path).exists():
            try:
                self.image_classifier = OnnxImageClassifier(path)
                log.info("Loaded trained ONNX deepfake classifier from %s", path)
            except Exception:  # noqa: BLE001
                log.exception("Failed to load ONNX model at %s — falling back to heuristic engine", path)

        gru_path = Path(path).with_suffix(".gru.npz") if path else None
        if gru_path and gru_path.exists():
            try:
                self.temporal_gru = NumpyGRU(str(gru_path))
                log.info("Loaded trained GRU temporal weights from %s", gru_path)
            except Exception:  # noqa: BLE001
                log.exception("Failed to load GRU weights at %s", gru_path)

    @property
    def available(self) -> bool:
        return self.image_classifier is not None


_backend: Optional[ModelBackend] = None


def get_model_backend() -> ModelBackend:
    global _backend
    if _backend is None:
        _backend = ModelBackend()
    return _backend
