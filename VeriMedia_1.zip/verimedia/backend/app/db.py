"""
Persistence layer for VeriMedia.

Speaks either SQLite (zero-config default, good for local dev and small
single-instance deployments) or PostgreSQL (for production — e.g. a
DigitalOcean App Platform app, whose containers have no persistent disk, so
a managed Postgres add-on is what actually keeps history/cache across
redeploys), picked automatically from `VERIMEDIA_DATABASE_URL`:

    sqlite:///relative/or/absolute/path.db        (default)
    postgresql://user:pass@host:5432/dbname        (production)

Every call site below writes SQL with `?` placeholders and goes through
`_exec()`, which adapts the placeholder style and cursor/row-shape
differences between `sqlite3` and `psycopg2` — so the query logic itself
(and everything above this module) never needs to know which database is
in use.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Optional

from .config import config

_DB_PATH = config.DATA_DIR / "verimedia.db"
_local = threading.local()

IS_POSTGRES = config.DATABASE_URL.startswith("postgres://") or config.DATABASE_URL.startswith("postgresql://")

if IS_POSTGRES:
    import psycopg2
    import psycopg2.extras

SCHEMA_COMMON = """
CREATE TABLE IF NOT EXISTS analyses (
    id TEXT PRIMARY KEY,
    media_type TEXT NOT NULL,
    source_url TEXT,
    content_hash TEXT,
    verdict TEXT NOT NULL,
    confidence REAL NOT NULL,
    summary TEXT,
    details_json TEXT,
    engine TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_analyses_created_at ON analyses (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_analyses_content_hash ON analyses (content_hash);

CREATE TABLE IF NOT EXISTS cache (
    cache_key TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    created_at REAL NOT NULL,
    expires_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    media_type TEXT NOT NULL,
    result_json TEXT,
    error TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def _adapt(sql: str) -> str:
    return sql.replace("?", "%s") if IS_POSTGRES else sql


def get_conn():
    """Thread-local connection (neither sqlite3 nor a single psycopg2
    connection is safe to share across threads, and Flask's threaded dev
    server / gunicorn worker threads / our task-queue workers each run on
    their own thread)."""
    conn = getattr(_local, "conn", None)
    if conn is None:
        if IS_POSTGRES:
            conn = psycopg2.connect(config.DATABASE_URL)
        else:
            path = config.DATABASE_URL.removeprefix("sqlite:///") or str(_DB_PATH)
            conn = sqlite3.connect(path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL;")
        _local.conn = conn
    return conn


def _exec(conn, sql: str, params: tuple = ()):
    """Returns a cursor-like object with .fetchone()/.fetchall() yielding
    dict-like rows, for either backend."""
    if IS_POSTGRES:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(_adapt(sql), params)
        return cur
    return conn.execute(sql, params)


def init_db() -> None:
    conn = get_conn()
    if IS_POSTGRES:
        with conn.cursor() as cur:
            cur.execute(SCHEMA_COMMON)
        conn.commit()
    else:
        conn.executescript(SCHEMA_COMMON)
        conn.commit()


@contextmanager
def tx():
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


# ---------------------------------------------------------------------------
# Analyses (history) helpers
# ---------------------------------------------------------------------------

def insert_analysis(
    *,
    media_type: str,
    source_url: Optional[str],
    content_hash: Optional[str],
    verdict: str,
    confidence: float,
    summary: str,
    details: dict,
    engine: str,
) -> dict:
    record_id = str(uuid.uuid4())
    now = time.time()
    with tx() as conn:
        _exec(
            conn,
            """INSERT INTO analyses
               (id, media_type, source_url, content_hash, verdict, confidence,
                summary, details_json, engine, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record_id, media_type, source_url, content_hash, verdict,
                confidence, summary, json.dumps(details), engine, now,
            ),
        )
    return {
        "id": record_id, "media_type": media_type, "source_url": source_url,
        "content_hash": content_hash, "verdict": verdict, "confidence": confidence,
        "summary": summary, "details": details, "engine": engine, "created_at": now,
    }


def list_analyses(limit: int = 50, offset: int = 0, media_type: Optional[str] = None) -> list[dict]:
    conn = get_conn()
    if media_type:
        rows = _exec(
            conn,
            "SELECT * FROM analyses WHERE media_type = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (media_type, limit, offset),
        ).fetchall()
    else:
        rows = _exec(
            conn,
            "SELECT * FROM analyses ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset),
        ).fetchall()
    return [_row_to_analysis(r) for r in rows]


def count_analyses() -> int:
    conn = get_conn()
    return _exec(conn, "SELECT COUNT(*) AS c FROM analyses").fetchone()["c"]


def analytics_overview() -> dict:
    conn = get_conn()
    total = _exec(conn, "SELECT COUNT(*) AS c FROM analyses").fetchone()["c"]
    safe = _exec(
        conn, "SELECT COUNT(*) AS c FROM analyses WHERE verdict IN ('authentic','true')"
    ).fetchone()["c"]
    suspicious = _exec(
        conn, "SELECT COUNT(*) AS c FROM analyses WHERE verdict IN ('suspicious','misleading')"
    ).fetchone()["c"]
    fake = _exec(
        conn, "SELECT COUNT(*) AS c FROM analyses WHERE verdict IN ('fake','false')"
    ).fetchone()["c"]

    if IS_POSTGRES:
        day_expr = "to_char(to_timestamp(created_at), 'YYYY-MM-DD')"
    else:
        day_expr = "date(created_at, 'unixepoch')"

    trend_rows = _exec(
        conn,
        f"""SELECT {day_expr} AS day,
                  SUM(CASE WHEN verdict IN ('authentic','true') THEN 1 ELSE 0 END) AS safe,
                  SUM(CASE WHEN verdict IN ('suspicious','misleading') THEN 1 ELSE 0 END) AS suspicious,
                  SUM(CASE WHEN verdict IN ('fake','false') THEN 1 ELSE 0 END) AS fake
           FROM analyses
           GROUP BY day
           ORDER BY day ASC
           LIMIT 30""",
    ).fetchall()
    return {
        "total": total,
        "safe_media": safe,
        "suspicious_items": suspicious,
        "deepfakes_blocked": fake,
        "activity_trend": [dict(r) for r in trend_rows],
    }


def _row_to_analysis(row) -> dict:
    d = dict(row)
    d["details"] = json.loads(d.pop("details_json") or "{}")
    return d


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def cache_get(key: str) -> Optional[dict]:
    conn = get_conn()
    row = _exec(conn, "SELECT payload_json, expires_at FROM cache WHERE cache_key = ?", (key,)).fetchone()
    if not row:
        return None
    if row["expires_at"] < time.time():
        with tx() as conn2:
            _exec(conn2, "DELETE FROM cache WHERE cache_key = ?", (key,))
        return None
    return json.loads(row["payload_json"])


def cache_set(key: str, payload: dict, ttl_seconds: int) -> None:
    now = time.time()
    with tx() as conn:
        _exec(
            conn,
            """INSERT INTO cache (cache_key, payload_json, created_at, expires_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(cache_key) DO UPDATE SET
                   payload_json = excluded.payload_json,
                   created_at = excluded.created_at,
                   expires_at = excluded.expires_at""",
            (key, json.dumps(payload), now, now + ttl_seconds),
        )


# ---------------------------------------------------------------------------
# Job helpers (async task queue for video analysis)
# ---------------------------------------------------------------------------

def create_job(job_id: str, media_type: str) -> None:
    now = time.time()
    with tx() as conn:
        _exec(
            conn,
            """INSERT INTO jobs (id, status, media_type, result_json, error, created_at, updated_at)
               VALUES (?, 'queued', ?, NULL, NULL, ?, ?)""",
            (job_id, media_type, now, now),
        )


def update_job(job_id: str, *, status: str, result: Optional[dict] = None, error: Optional[str] = None) -> None:
    with tx() as conn:
        _exec(
            conn,
            """UPDATE jobs SET status = ?, result_json = ?, error = ?, updated_at = ?
               WHERE id = ?""",
            (status, json.dumps(result) if result is not None else None, error, time.time(), job_id),
        )


def get_job(job_id: str) -> Optional[dict]:
    conn = get_conn()
    row = _exec(conn, "SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["result"] = json.loads(d.pop("result_json")) if d.get("result_json") else None
    return d


# ---------------------------------------------------------------------------
# Settings (key/value) helpers
# ---------------------------------------------------------------------------

def get_setting(key: str, default: Any = None) -> Any:
    conn = get_conn()
    row = _exec(conn, "SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with tx() as conn:
        _exec(
            conn,
            """INSERT INTO settings (key, value) VALUES (?, ?)
               ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
            (key, value),
        )
