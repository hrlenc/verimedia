"""
VeriMedia backend configuration.

Everything here is overridable via environment variables (or a `.env` file
loaded by python-dotenv), so the same code runs unchanged whether it's
sitting on a laptop with SQLite or deployed behind Postgres + Celery.
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


class Config:
    # --- General ---
    ENV = os.environ.get("VERIMEDIA_ENV", "development")
    DEBUG = _bool("VERIMEDIA_DEBUG", ENV == "development")
    HOST = os.environ.get("VERIMEDIA_HOST", "127.0.0.1")
    PORT = int(os.environ.get("VERIMEDIA_PORT", "8000"))

    # --- Storage ---
    DATA_DIR = Path(os.environ.get("VERIMEDIA_DATA_DIR", BASE_DIR / "data"))
    DATABASE_URL = os.environ.get(
        "VERIMEDIA_DATABASE_URL", f"sqlite:///{DATA_DIR / 'verimedia.db'}"
    )
    # Swap to a real Postgres URL in production, e.g.:
    #   postgresql://user:pass@host:5432/verimedia
    # The db layer only speaks sqlite3 today (see app/db.py); a Postgres
    # adapter is a documented, isolated swap (see README "Scaling to
    # Postgres").

    # --- CORS ---
    # The extension calls this API from a chrome-extension:// origin, and
    # from the dashboard/options page. Restrict in production to your
    # actual extension ID(s).
    ALLOWED_ORIGINS = os.environ.get("VERIMEDIA_ALLOWED_ORIGINS", "*")

    # --- Deepfake pipeline thresholds ---
    # Composite manipulation score (0-1) above which content is flagged.
    DEEPFAKE_FLAG_THRESHOLD = float(os.environ.get("VERIMEDIA_DEEPFAKE_THRESHOLD", "0.55"))
    DEEPFAKE_SUSPICIOUS_THRESHOLD = float(os.environ.get("VERIMEDIA_DEEPFAKE_SUSPICIOUS", "0.35"))
    # Max video frames sampled per analysis (keeps latency bounded on CPU).
    VIDEO_MAX_FRAMES = int(os.environ.get("VERIMEDIA_VIDEO_MAX_FRAMES", "24"))

    # --- Misinformation pipeline thresholds ---
    MISINFO_FALSE_THRESHOLD = float(os.environ.get("VERIMEDIA_MISINFO_FALSE", "0.62"))
    MISINFO_TRUE_THRESHOLD = float(os.environ.get("VERIMEDIA_MISINFO_TRUE", "0.62"))
    RETRIEVAL_TOP_K = int(os.environ.get("VERIMEDIA_RETRIEVAL_TOP_K", "5"))

    # --- Optional deep model backend (see app/pipelines/model_backend.py) ---
    ONNX_DEEPFAKE_MODEL_PATH = os.environ.get("VERIMEDIA_ONNX_MODEL_PATH", "")

    # --- Optional live retrieval backend (see app/pipelines/retrieval_backend.py) ---
    LIVE_RETRIEVAL_PROVIDER = os.environ.get("VERIMEDIA_RETRIEVAL_PROVIDER", "")  # "" | "google_fact_check" | "bing" | "newsapi"
    LIVE_RETRIEVAL_API_KEY = os.environ.get("VERIMEDIA_RETRIEVAL_API_KEY", "")

    # --- Cache ---
    CACHE_TTL_SECONDS = int(os.environ.get("VERIMEDIA_CACHE_TTL", str(60 * 60 * 24 * 7)))  # 7 days


config = Config()
config.DATA_DIR.mkdir(parents=True, exist_ok=True)
