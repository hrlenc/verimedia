"""Entry point: `python run.py` starts the VeriMedia backend."""
from app import create_app
from app.config import config

app = create_app()

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG, threaded=True)
